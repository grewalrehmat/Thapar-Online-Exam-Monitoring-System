const labId = document.body.dataset.labId;
const secure = document.body.dataset.secure === "true";
const code = document.getElementById("code");
const saveStatus = document.getElementById("saveStatus");
const stdout = document.getElementById("stdout");
const stderr = document.getElementById("stderr");

let saveTimer;

async function post(url, body) {
    const res = await fetch(url, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(body)
    });
    return res.json();
}

function scheduleSave() {
    saveStatus.textContent = "Saving...";
    clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
        await post(`/api/labs/${labId}/draft`, {code: code.value});
        saveStatus.textContent = "Saved";
    }, 900);
}

code.addEventListener("input", scheduleSave);

document.getElementById("runBtn").addEventListener("click", async () => {
    stdout.textContent = "Running...";
    stderr.textContent = "";
    const result = await post(`/api/labs/${labId}/run`, {code: code.value});
    stdout.textContent = result.stdout || "(no output)";
    stderr.textContent = result.stderr || "";
});

document.getElementById("submitBtn").addEventListener("click", async () => {
    if (!confirm("Submit your final code? You will not be able to edit it afterwards.")) return;
    const result = await post(`/api/labs/${labId}/submit`, {code: code.value});
    if (result.status === "submitted") {
        alert("Submitted successfully.");
        location.reload();
    }
});

async function event(type, metadata = null) {
    if (!secure) return;
    await post(`/api/labs/${labId}/activity`, {type, metadata});
}

document.addEventListener("visibilitychange", () => {
    if (document.hidden) event("TAB_SWITCH");
});

document.addEventListener("copy", () => event("COPY"));
document.addEventListener("paste", () => event("PASTE"));
document.addEventListener("cut", () => event("CUT"));

document.addEventListener("fullscreenchange", () => {
    if (!document.fullscreenElement) event("FULLSCREEN_EXIT");
});

