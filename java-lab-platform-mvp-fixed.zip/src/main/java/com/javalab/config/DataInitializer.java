package com.javalab.config;

import com.javalab.model.*;
import com.javalab.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner seed(UserRepository users, LabRepository labs, PasswordEncoder encoder) {
        return args -> {
            if (users.count() > 0) return;

            users.save(new User(
                    "Demo Teacher", "teacher@javalab.local", null,
                    encoder.encode("teacher123"), Role.TEACHER));

            users.save(new User(
                    "Rehmatjot Singh", "student@javalab.local", "23BCS001",
                    encoder.encode("student123"), Role.STUDENT));

            users.save(new User(
                    "Demo Student", "student2@javalab.local", "23BCS002",
                    encoder.encode("student123"), Role.STUDENT));

            labs.save(new LabSession(
                    "Java OOP Evaluation",
                    "Write a Java program demonstrating inheritance and method overriding.",
                    LocalDateTime.now().minusMinutes(10),
                    LocalDateTime.now().plusHours(3),
                    LabStatus.ACTIVE,
                    true));
        };
    }
}
