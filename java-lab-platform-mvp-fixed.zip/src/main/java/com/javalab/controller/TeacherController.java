package com.javalab.controller;

import com.javalab.model.SubmissionStatus;
import com.javalab.repository.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/teacher")
public class TeacherController {

    private final LabRepository labs;
    private final SubmissionRepository submissions;
    private final ActivityRepository activities;

    public TeacherController(LabRepository labs, SubmissionRepository submissions,
                             ActivityRepository activities) {
        this.labs = labs;
        this.submissions = submissions;
        this.activities = activities;
    }

    @GetMapping("/lab/{id}")
    String monitor(@PathVariable Long id, Model model) {
        var lab = labs.findById(id).orElseThrow();
        model.addAttribute("lab", lab);
        model.addAttribute("submissions", submissions.findByLabId(id));
        model.addAttribute("activities", activities.findTop100ByLabIdOrderByTimestampDesc(id));
        return "teacher-monitor";
    }

    @PostMapping("/submission/{id}/grade")
    String grade(@PathVariable Long id,
                 @RequestParam Integer score,
                 @RequestParam(required = false) String feedback) {
        var submission = submissions.findById(id).orElseThrow();
        submission.setScore(Math.max(0, Math.min(100, score)));
        submission.setFeedback(feedback);
        submissions.save(submission);
        return "redirect:/teacher/lab/" + submission.getLab().getId();
    }
}
